import React from 'react';

const aux = (props) => {
    return(
        <div>
            {props.children}
        </div>
    );
}

export default aux;